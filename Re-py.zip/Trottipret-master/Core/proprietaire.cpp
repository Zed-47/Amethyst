#include "proprietaire.h"

Proprietaire::Proprietaire()
{
    // ctor vide
}
